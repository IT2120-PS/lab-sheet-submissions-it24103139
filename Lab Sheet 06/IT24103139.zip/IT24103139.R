setwd("C:\\Users\\it24103139\\Desktop")

# 1.1 
n <- 50
p <- 0.85
cat("X ~ Binomial(n =", n, ", p =", p, ")\n")

# 1.2
prob_at_least_47 <- pbinom(46, size = n, prob = p, lower.tail = FALSE)
cat(sprintf("P(X >= 47) = %.6f\n", prob_at_least_47))

# 2.1
cat("X = Number of customer calls received in one hour\n")

# 2.2
lambda <- 12
cat("X ~ Poisson(lambda =", lambda, ")\n")

# 2.3
prob_eq_15 <- dpois(15, lambda = lambda)
cat(sprintf("P(X = 15) = %.6f\n", prob_eq_15))

